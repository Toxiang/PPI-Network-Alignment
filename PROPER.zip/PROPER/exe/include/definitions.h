#pragma once

#ifndef DEFINITIONS_H
#define DEFINITIONS_H

#include <list>
#include <map>
#include <string>
#include <utility>

#define SEPARATOR "$" /**< String separator used as a token for tokenization and untokenization */

#define TMP_DIR "./_tmp" /**< @deprecated Used for file operations. Should be removed in next version! */
#define TMP_EGO TMP_DIR "/tmp_ego" /**< @deprecated Used for file operations. Should be removed in next version! */
#define TMP_LABEL TMP_DIR "/tmp_label" /**< @deprecated Used for file operations. Should be removed in next version! */
#define TMP_GRAPH TMP_DIR "/tmp_graph" /**< @deprecated Used for file operations. Should be removed in next version! */

/** Exceptions that can be raised in the middle of the code. Normally, whenever one of them occurs, the filename and line are displayed */
enum EXCEPTIONS {
                    NO_GRAPH, /**< Graph not created when method was called */
                    ALLOC_EXCEPTION, /**< Memory reallocation */
                    SEGFAULT /**< Common Segmentation Fault */
                };
/**
    Simple structure to store an edge where the endpoints have integer values.
*/
struct Edge
{
    int u, /**< Source endpoint */
        v; /**< Destination endpoint */
};


struct Match
{
	int lnode;
	int rnode;
	int value;
};

/*struct Tuple
{
	std::vector<int> vec;
	int value;
};

struct CompareTuples
{
  bool operator()(const Tuple & lhs, const Tuple & rhs) {
	if(lhs.value != rhs.value)
	{
		return lhs.value > rhs.value;
	}
	else
	{
		for(int i = 0; i < lhs.vec.size(); i++)
		{
			
		}
	}
		
  }
};*/



struct BlastVal
{
    std::string s; 
	int sp1;
	int sp2;
    int val;
};

struct CompareBlastVals
{
	bool operator()(const BlastVal & lhs, const BlastVal & rhs) {
		 if(lhs.val == rhs.val)
		{
			return lhs.s > rhs.s;
		}
		else
		{
			return lhs.val > rhs.val;
		}
	}

};
struct Triplet
{
	int node1;
	int node2;
	int node3;
	int value;
};
struct CompareTriplets
{
  bool operator()(const Triplet & lhs, const Triplet & rhs) {
	  if(lhs.value == rhs.value)
	  {
		if(lhs.node1 == rhs.node1)
		{
			if(lhs.node2 == rhs.node2)
		  	{
				return lhs.node3 > rhs.node3;
			}
			else
			{
				return lhs.node2 > rhs.node2;
			}
		
		}
		else
		{
			return lhs.node1 > rhs.node1;
		}
	  }
	  else
	  {
		return lhs.value > rhs.value;
	  }
  }
};


struct CompareMatches
{
  bool operator()(const Match & lhs, const Match & rhs) {
	  if(lhs.value == rhs.value)
	  {
		  if(lhs.lnode == rhs.lnode)
		  {
			  return ((((lhs.rnode * 0xf7f7f7f7) ^ 0x8364abf7) * 0xf00bf00b) ^ 0xf81bc437) > ((((rhs.rnode * 0xf7f7f7f7) ^ 0x8364abf7) * 0xf00bf00b) ^ 0xf81bc437);
		  }
		  return ((((lhs.lnode ^ 0xf7f7f7f7) * 0x8364abf7) ^ 0xf00bf00b) * 0xf81bc437) < ((((rhs.lnode ^ 0xf7f7f7f7) * 0x8364abf7) ^ 0xf00bf00b) * 0xf81bc437 );
	  }
	  else
	  {
		  return lhs.value > rhs.value;
	  }
  }
};

struct ProtPair
{
    int prot1,
		sp1,
        prot2,
		sp2,
		value; 
};

struct CompareProtPairs
{
  bool operator()(const ProtPair & lhs, const ProtPair & rhs) {
	  if(lhs.value == rhs.value)
	  {
		  if(lhs.prot1 == rhs.prot1)
		  {
			if(lhs.prot2 == rhs.prot2)
			{
				if(lhs.sp1 == rhs.sp1)
				{
					return (lhs.sp2 < rhs.sp2);
				}
				return (lhs.sp1 < rhs.sp1);
			}
			return (lhs.prot2 > rhs.prot2);
		  }
		  return (lhs.prot1 > rhs.prot1);
	  }
	  else
	  {
		  return (lhs.value > rhs.value);
	  }
  }
};


struct BlasPair
{
	int node1;
	int node2;
	float blast;
};


struct CompareBlasPair
{
bool operator()(const BlasPair & lhs, const BlasPair & rhs) {
	  if(lhs.blast == rhs.blast)
	  {
			if(lhs.node1 == rhs.node2)		  
				return lhs.node2 < rhs.node2;
			else
				return lhs.node1 < rhs.node1;
	  }
	  else
	  {		  
			return lhs.blast > rhs.blast;
	  }
  }
};
struct NodeVal
{
	int rnode;
	int value;
};
struct CompareNodeVal
{
bool operator()(const NodeVal & lhs, const NodeVal & rhs) {
	  if(lhs.value == rhs.value)
	  {
		  return lhs.rnode > rhs.rnode;
	  }
	  else
	  {
		  return lhs.value > rhs.value;
	  }
  }
};

#endif

