//Written by Ehsan Kazemi ehsan.kazemi66@gmail.com
#include <iostream>
#include <cstdlib>
#include <string>
#include <sstream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <graph.h>
using namespace std;


int main( int argc, char * argv[] )
{
	srand( time( NULL ) );
	string graph_filel =  argv[ 1 ];
	string graph_filer = argv[ 2 ];
	string blastfile = argv[ 3 ];
	string filename = argv[ 6 ];
	
	int r		= atoi( argv[ 4] ) - 1;
	int tie		= 1;
	bool tie_break = true;
	if (tie == 0)
		tie_break = false;
		
	int nb_seed		= 10000000; //maximum number of possibe pairs for the initial seed set
	int min_blast		= atoi( argv[ 5 ] );


	Graph * lg = new Graph( false);
	lg->readGraph( graph_filel );
	int N = lg->getNNodes();
	Graph * rg = new Graph( false);
	rg->readGraph( graph_filer );
	N = rg->getNNodes();
	cout << "Number of nodes in the first graph: "<< lg->getNNodes() << endl;
	cout << "Number of edges in the first graph: "<< lg->getNEdges() << endl;
	cout << "Number of nodes in the second graph: "<< rg->getNNodes() << endl;
	cout << "Number of edges in the second graph: "<< rg->getNEdges() << endl;
	std::map<int , string> linttonodeID = lg->getinttonodeID();
	std::map<int , string> rinttonodeID = rg->getinttonodeID();
	std::map<string , int> lnodeIDtoint = lg->getnodeIDtoint();
	std::map<string , int> rnodeIDtoint = rg->getnodeIDtoint();
	
	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	//read and sort the blast file
	ifstream file;
	file.open( blastfile.c_str() );
	string s1, s2;
	float blast;
	std::set<BlasPair, CompareBlasPair> blasts;
	Match m;
	std::list< Match> seed;
	while (file >> s1 >> s2 >> blast)
	{
		if (blast >= min_blast)
		{
			m.lnode = lnodeIDtoint[s1]; m.rnode = rnodeIDtoint[s2]; m.value = (int) blast;
			seed.push_back(m);
		}
		
	}
	file.close();

	cout << "Number of couples with BLAST bit-score at least " << min_blast << ": " << seed.size() << endl;
	std::set<Match, CompareMatches> matches = lg->proper(*rg, seed,r, tie_break);
	ofstream output( filename.c_str() );
	for (auto it = matches.begin(); it != matches.end(); ++it )
	{
		output << linttonodeID[it->lnode] << "\t" << rinttonodeID[it->rnode] << std::endl;
	}
	delete lg;
	delete rg;
	seed.clear();
	matches.clear();
	output.close();
	return 0;
}
