#Python version 2.7.3 (default, Mar 13 2014, 11:03:55) 
#[GCC 4.7.2]
import pickle
import numpy as np
import networkx as nx
from collections import defaultdict
import sys


def intersect(a, b):
     return list(set(a) & set(b))

def union(a, b):
     return list(set(a) | set(b))

if (__name__ == '__main__'):
	
	filename1 = 'F:/complex/PROPER/PROPER/networks/ce.interaction'# first network
	filename2 = 'F:/complex/PROPER/PROPER/networks/dm.interaction'# second network
	match_file = 'F:/complex/PROPER/PROPER/output3.txt' # matched file
	GO1 = pickle.load(open("../GO_terms/experimental.dat", "rb"))
	GO2 = GO1
	f = open( match_file, 'r' )
	go =0
	gocorrect = 0
	tot = 0
	for line in f:
		parsed = line.replace( "\n", "" ).split()
		prot1 = parsed[0]
		prot2 = parsed[1]
		tot+= 1
		if prot1 in GO1 and prot2 in GO2:
			if len(GO1[prot1]) > 0 and len(GO2[prot2]) > 0:
				go+=1
				intsec = intersect(GO1[prot1], GO2[prot2])
				un = union(GO1[prot1], GO2[prot2])
				if len(intsec) > 0:
					gocorrect+=(len(intsec) * 1.0 / len(un))
	c0 =  gocorrect

	GO1 = pickle.load(open("../GO_terms/all.dat", "rb"))
	GO2 = GO1
	f = open( match_file, 'r' )
	go =0
	gocorrect = 0
	tot = 0
	for line in f:
		parsed = line.replace( "\n", "" ).split()
		prot1 = parsed[0]
		prot2 = parsed[1]
		tot+= 1
		if prot1 in GO1 and prot2 in GO2:
			if len(GO1[prot1]) > 0 and len(GO2[prot2]) > 0:
				go+=1
				intsec = intersect(GO1[prot1], GO2[prot2])
				un = union(GO1[prot1], GO2[prot2])
				if len(intsec) > 0:
					gocorrect+=(len(intsec) * 1.0 / len(un))
	call =  gocorrect

	f = open( filename1, 'r' )
	G1 = nx.Graph()
	cnt = 0
	for line in f:
		cnt+=1
		if cnt == 1: continue
		parsed = line.replace( "\n", "" ).split()
		G1.add_edge(parsed[0], parsed[1])

	f = open( filename2, 'r' )
	G2 = nx.Graph()
	cnt = 0
	for line in f:
		cnt+=1
		if cnt == 1: continue
		parsed = line.replace( "\n", "" ).split()
		G2.add_edge(parsed[0], parsed[1])

	f = open( match_file, 'r' )
	dict_match = dict()
	nodes = []
	nodes2 = []
	for line in f:
		parsed = line.replace( "\n", "" ).split()
		prot1 = parsed[0]
		prot2 = parsed[1]
		dict_match[prot1] = prot2
		nodes.append(prot1)
		nodes2.append(prot2)
	size = len(nodes)
	H = G1.subgraph(nodes)
	H2 = G2.subgraph(nodes2)
	tot_edge = 0
	correct_edge = 0
	G12 = nx.Graph()
	for node in nodes:
		G12.add_node(node)
	for e in H.edges():
		if e[0] in dict_match and e[1] in dict_match:
			tot_edge += 1
			if G2.has_edge(dict_match[e[0]],dict_match[e[1]]):
				G12.add_edge(e[0],e[1])
				correct_edge += 1
	tot_edge2 = 0
	for e in H2.edges():
		if e[0] in nodes2 and e[1] in nodes2:
			tot_edge2 += 1
	tot = tot_edge
	tot0 = tot_edge2
	if len(G2.nodes()) > len(G1.nodes()):
		tot = tot_edge2
		tot0 = tot_edge
	c3 = len(G12.edges()) * 1.0 / tot
	c4 = len(G12.edges()) * 1.0 / tot0
 	c5 = len(list(nx.connected_component_subgraphs(G12))[0].nodes())
	c6 = nx.average_clustering(G12)
	c7 = sum(nx.triangles(G12).values())
	c8 = len(G12.edges())
	c9 = len(G12.edges()) / (size * 1.0)
	if len(G1.nodes()) < len(G2.nodes()):
		c10 = len(G12.edges()) * 1.0 / len(G1.edges())
		EGf = len(G2.subgraph(nodes2).edges())
		c11 = len(G12.edges()) * 1.0 / (len(G1.edges()) + EGf - len(G12.edges()) * 1.0)
	else:
		c10 = len(G12.edges()) * 1.0 / len(G2.edges())
		EGf = len(G1.subgraph(nodes).edges())
		c11 = len(G12.edges()) * 1.0 / (len(G2.edges()) + EGf - len(G12.edges()) * 1.0)
	
	#print size, '\t', c0, '\t', c3,'\t', c4,'\t', c5, '\t',c6,'\t', c7,'\t', c8,'\t', c9,'\t', c10,'\t', c11
	print "Number of aligned couples: ", size
	print "GOC score (all): ", call
	print "GOC score (experimental): ", c0
	print "ICS ", c3
	print "LCSC: ", c5
	print "EC: ", c10
	print "S3:", c11
